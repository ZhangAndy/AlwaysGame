first lua
